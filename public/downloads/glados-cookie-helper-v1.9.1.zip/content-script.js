(() => {
  const PAGE_SOURCE = 'glados-checkin-console'
  const EXTENSION_SOURCE = 'glados-cookie-helper'

  // Replace our listener on reconnect so an extension reload does not reuse an
  // invalidated runtime context. Keep the handler reachable for the next injection.
  const previous = window.__gladosCookieHelperBridgeInstalled
  if (typeof previous === 'function') window.removeEventListener('message', previous)

  const receive = async (event) => {
    if (event.source !== window || event.origin !== window.location.origin) return
    const message = event.data
    if (!message || message.source !== PAGE_SOURCE || message.type !== 'GLADOS_COOKIE_IMPORT_REQUEST' || !message.requestId) return

    try {
      const response = await chrome.runtime.sendMessage({ type: 'READ_GLADOS_SESSION' })
      window.postMessage({
        source: EXTENSION_SOURCE,
        type: 'GLADOS_COOKIE_IMPORT_RESPONSE',
        requestId: message.requestId,
        ...response,
      }, window.location.origin)
    } catch (error) {
      window.postMessage({
        source: EXTENSION_SOURCE,
        type: 'GLADOS_COOKIE_IMPORT_RESPONSE',
        requestId: message.requestId,
        ok: false,
        error: error.message || '浏览器扩展读取失败',
      }, window.location.origin)
    }
  }
  window.__gladosCookieHelperBridgeInstalled = receive
  window.addEventListener('message', receive)
  window.postMessage({ source: EXTENSION_SOURCE, type: 'GLADOS_COOKIE_HELPER_READY' }, window.location.origin)
})()
